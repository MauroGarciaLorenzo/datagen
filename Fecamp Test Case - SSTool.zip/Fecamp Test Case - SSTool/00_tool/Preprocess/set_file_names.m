%% SET FILE NAMES

% Create excel file names

excel    = [caseName '.xlsx']; 
data_sg  = [caseName '_data_sg.xlsx'];
data_vsc = [caseName '_data_vsc.xlsx'];

% Simulink models names
linear    =  ['IEEE118_FULL_LIN'];
nonlinear = ['IEEE118_FULL'];

