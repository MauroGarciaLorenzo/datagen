function [vec_p, vec_q] = vec_pq(g)

% vec_p = g.bus;
vec_p = g.pqpv;
vec_q = g.pq;

end

