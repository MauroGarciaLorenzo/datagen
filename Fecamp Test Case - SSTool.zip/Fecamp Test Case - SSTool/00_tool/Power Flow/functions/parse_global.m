function g = parse_global(g)
g.Vb    = g.glob.Vb_kV;
g.Sb    = g.glob.Sb_MVA;
g.fref  = g.glob.f_Hz;
end

