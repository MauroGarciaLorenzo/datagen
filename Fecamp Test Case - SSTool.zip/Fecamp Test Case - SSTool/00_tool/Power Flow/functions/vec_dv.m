function [vec_d, vec_v] = vec_dv(g)

vec_d = g.pqpv;
vec_v = g.pq;

end

